"use client"

import { useState } from "react"
import { Badge } from "@/components/ui/badge"
import { Card } from "@/components/ui/card"
import type { Automaton, Transition } from "../types/automata"

interface InteractiveDiagramProps {
  automaton: Automaton
  highlightedStates: string[]
  highlightedTransitions: Transition[]
}

export function InteractiveDiagram({ automaton, highlightedStates, highlightedTransitions }: InteractiveDiagramProps) {
  const [selectedState, setSelectedState] = useState<string | null>(null)
  const [hoveredTransition, setHoveredTransition] = useState<Transition | null>(null)

  const getStatePosition = (index: number, total: number) => {
    const angle = (2 * Math.PI * index) / total
    const radius = Math.min(150, 50 + total * 8)
    const centerX = 200
    const centerY = 150
    return {
      x: centerX + radius * Math.cos(angle),
      y: centerY + radius * Math.sin(angle),
    }
  }

  const statePositions = automaton.states.reduce(
    (acc, state, index) => {
      acc[state] = getStatePosition(index, automaton.states.length)
      return acc
    },
    {} as Record<string, { x: number; y: number }>,
  )

  const groupedTransitions = automaton.transitions.reduce(
    (acc, transition) => {
      const key = `${transition.from}-${transition.to}`
      if (!acc[key]) {
        acc[key] = []
      }
      acc[key].push(transition)
      return acc
    },
    {} as Record<string, Transition[]>,
  )

  const renderTransition = (transitions: Transition[], key: string) => {
    const from = statePositions[transitions[0].from]
    const to = statePositions[transitions[0].to]

    if (!from || !to) return null

    const isSelfLoop = transitions[0].from === transitions[0].to
    const isHighlighted = highlightedTransitions.some((ht) =>
      transitions.some((t) => t.from === ht.from && t.to === ht.to && t.symbol === ht.symbol),
    )

    // Sort symbols and ensure epsilon is displayed correctly
    const symbols = transitions
      .map((t) => (t.symbol === "ε" || t.symbol === "epsilon" ? "ε" : t.symbol))
      .sort()
      .join(", ")

    if (isSelfLoop) {
      const loopRadius = 20 // Reduced from 25
      const centerX = from.x
      const centerY = from.y - 35 // Reduced from 45

      return (
        <g key={key}>
          <circle
            cx={centerX}
            cy={centerY}
            r={loopRadius}
            fill="none"
            stroke={isHighlighted ? "#ef4444" : "#6b7280"}
            strokeWidth={isHighlighted ? 2 : 1.5} // Reduced thickness
            className="cursor-pointer"
            onMouseEnter={() => setHoveredTransition(transitions[0])}
            onMouseLeave={() => setHoveredTransition(null)}
          />
          {/* Smaller arrow for self-loop */}
          <polygon
            points={`${centerX + 12},${centerY + 12} ${centerX + 16},${centerY + 8} ${centerX + 8},${centerY + 8}`}
            fill={isHighlighted ? "#ef4444" : "#6b7280"}
          />
          <text
            x={centerX}
            y={centerY - 25} // Adjusted position
            textAnchor="middle"
            className="text-xs font-medium"
            fill={isHighlighted ? "#ef4444" : "#374151"}
          >
            {symbols}
          </text>
        </g>
      )
    }

    const dx = to.x - from.x
    const dy = to.y - from.y
    const length = Math.sqrt(dx * dx + dy * dy)
    const unitX = dx / length
    const unitY = dy / length

    const radius = 25
    const startX = from.x + unitX * radius
    const startY = from.y + unitY * radius
    const endX = to.x - unitX * radius
    const endY = to.y - unitY * radius

    // Smaller arrow head
    const arrowLength = 8 // Reduced from 12
    const arrowAngle = Math.PI / 7 // Slightly narrower angle
    const angle = Math.atan2(dy, dx)

    const arrowX1 = endX - arrowLength * Math.cos(angle - arrowAngle)
    const arrowY1 = endY - arrowLength * Math.sin(angle - arrowAngle)
    const arrowX2 = endX - arrowLength * Math.cos(angle + arrowAngle)
    const arrowY2 = endY - arrowLength * Math.sin(angle + arrowAngle)

    // Better label positioning - offset from line
    const labelX = (startX + endX) / 2
    const labelY = (startY + endY) / 2 - 8 // Reduced offset

    return (
      <g key={key}>
        <line
          x1={startX}
          y1={startY}
          x2={endX}
          y2={endY}
          stroke={isHighlighted ? "#ef4444" : "#6b7280"}
          strokeWidth={isHighlighted ? 2 : 1.5} // Reduced thickness
          className="cursor-pointer"
          onMouseEnter={() => setHoveredTransition(transitions[0])}
          onMouseLeave={() => setHoveredTransition(null)}
        />
        {/* Smaller arrow head */}
        <polygon
          points={`${endX},${endY} ${arrowX1},${arrowY1} ${arrowX2},${arrowY2}`}
          fill={isHighlighted ? "#ef4444" : "#6b7280"}
        />
        <text
          x={labelX}
          y={labelY}
          textAnchor="middle"
          className="text-xs font-medium"
          fill={isHighlighted ? "#ef4444" : "#374151"}
        >
          {symbols}
        </text>
      </g>
    )
  }

  return (
    <div className="space-y-4">
      <div className="relative">
        <svg width="400" height="300" className="border rounded-lg bg-white">
          {Object.entries(groupedTransitions).map(([key, transitions]) => renderTransition(transitions, key))}

          {automaton.states.map((state) => {
            const pos = statePositions[state]
            const isStart = state === automaton.startState
            const isFinal = automaton.finalStates.includes(state)
            const isHighlighted = highlightedStates.includes(state)
            const isSelected = selectedState === state

            return (
              <g key={state}>
                {isStart && (
                  <polygon
                    points={`${pos.x - 35},${pos.y} ${pos.x - 25},${pos.y - 4} ${pos.x - 25},${pos.y + 4}`}
                    fill="#10b981"
                  />
                )}

                {isFinal && <circle cx={pos.x} cy={pos.y} r={30} fill="none" stroke="#374151" strokeWidth={2} />}

                <circle
                  cx={pos.x}
                  cy={pos.y}
                  r={25}
                  fill={isSelected ? "#dbeafe" : isHighlighted ? "#fef3c7" : "white"}
                  stroke={isHighlighted ? "#f59e0b" : "#374151"}
                  strokeWidth={isHighlighted ? 3 : 2}
                  className="cursor-pointer hover:fill-gray-50"
                  onClick={() => setSelectedState(selectedState === state ? null : state)}
                />

                <text
                  x={pos.x}
                  y={pos.y + 5}
                  textAnchor="middle"
                  className="text-sm font-medium pointer-events-none"
                  fill="#374151"
                >
                  {state}
                </text>
              </g>
            )
          })}
        </svg>

        {selectedState && (
          <Card className="absolute top-4 right-4 p-3 max-w-xs">
            <div className="space-y-2">
              <div className="font-medium">State: {selectedState}</div>
              <div className="space-y-1 text-sm">
                {selectedState === automaton.startState && <Badge variant="secondary">Start State</Badge>}
                {automaton.finalStates.includes(selectedState) && <Badge variant="default">Final State</Badge>}
              </div>
              <div className="text-xs text-muted-foreground">
                <div>Outgoing transitions:</div>
                {automaton.transitions
                  .filter((t) => t.from === selectedState)
                  .map((t, i) => (
                    <div key={i}>
                      • {t.symbol} → {t.to}
                    </div>
                  ))}
              </div>
            </div>
          </Card>
        )}

        {hoveredTransition && (
          <Card className="absolute bottom-4 left-4 p-2">
            <div className="text-sm">
              {hoveredTransition.from} → <Badge variant="outline">{hoveredTransition.symbol}</Badge> →{" "}
              {hoveredTransition.to}
            </div>
          </Card>
        )}
      </div>

      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 border-2 border-green-500 bg-white rounded-full"></div>
          <span>Start State</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 border-2 border-gray-400 bg-white rounded-full relative">
            <div className="absolute inset-1 border border-gray-400 rounded-full"></div>
          </div>
          <span>Final State</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 border-2 border-amber-500 bg-amber-100 rounded-full"></div>
          <span>Highlighted</span>
        </div>
      </div>
    </div>
  )
}
