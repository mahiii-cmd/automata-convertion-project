"use client"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import type { Automaton } from "../types/automata"

interface TransitionTableProps {
  automaton: Automaton
  highlightedStates: string[]
}

export function TransitionTable({ automaton, highlightedStates }: TransitionTableProps) {
  // Sort alphabet with epsilon at the end for better display
  const sortedAlphabet = [...automaton.alphabet].sort((a, b) => {
    if (a === "ε" || a === "epsilon") return 1
    if (b === "ε" || b === "epsilon") return -1
    return a.localeCompare(b)
  })

  const tableData = automaton.states.map((state) => {
    const row: Record<string, string[]> = { state: [state] }

    for (const symbol of sortedAlphabet) {
      const transitions = automaton.transitions.filter(
        (t) => t.from === state && (t.symbol === symbol || (symbol === "ε" && t.symbol === "epsilon")),
      )
      row[symbol] = transitions.map((t) => t.to).sort()
    }

    return row
  })

  return (
    <div className="space-y-4">
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="font-semibold">State</TableHead>
              {sortedAlphabet.map((symbol) => (
                <TableHead key={symbol} className="font-semibold text-center">
                  {symbol === "epsilon" ? "ε" : symbol}
                </TableHead>
              ))}
            </TableRow>
          </TableHeader>
          <TableBody>
            {tableData.map((row, index) => {
              const state = row.state[0]
              const isHighlighted = highlightedStates.includes(state)
              const isStart = state === automaton.startState
              const isFinal = automaton.finalStates.includes(state)

              return (
                <TableRow key={state} className={isHighlighted ? "bg-amber-50" : ""}>
                  <TableCell className="font-medium">
                    <div className="flex items-center gap-2">
                      <span>{state}</span>
                      {isStart && (
                        <Badge variant="secondary" className="text-xs">
                          Start
                        </Badge>
                      )}
                      {isFinal && (
                        <Badge variant="default" className="text-xs">
                          Final
                        </Badge>
                      )}
                    </div>
                  </TableCell>
                  {sortedAlphabet.map((symbol) => (
                    <TableCell key={symbol} className="text-center">
                      {row[symbol] && row[symbol].length > 0 ? (
                        <div className="flex flex-wrap gap-1 justify-center">
                          {row[symbol].map((target, i) => (
                            <Badge key={i} variant="outline" className="text-xs">
                              {target}
                            </Badge>
                          ))}
                        </div>
                      ) : (
                        <span className="text-muted-foreground">∅</span>
                      )}
                    </TableCell>
                  ))}
                </TableRow>
              )
            })}
          </TableBody>
        </Table>
      </div>

      <div className="text-xs text-muted-foreground">
        <div className="font-medium mb-1">Table Legend:</div>
        <div>• ∅ represents no transition (empty set)</div>
        <div>• Multiple states in a cell indicate non-deterministic transitions</div>
        <div>• Highlighted rows show states being processed in current step</div>
        <div>• ε represents epsilon (empty string) transitions</div>
      </div>
    </div>
  )
}
