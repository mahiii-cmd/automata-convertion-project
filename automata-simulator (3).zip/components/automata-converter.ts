import type { Automaton, ConversionMode, ConversionStep, Transition } from "../types/automata"

export class AutomataConverter {
  async convert(automaton: Automaton, mode: ConversionMode): Promise<ConversionStep[]> {
    switch (mode) {
      case "nfa-to-dfa":
        return this.nfaToDfa(automaton)
      case "enfa-to-nfa":
        return this.enfaToNfa(automaton)
      case "enfa-to-dfa":
        return this.enfaToDfa(automaton)
      case "dfa-to-nfa":
        return this.dfaToNfa(automaton)
      case "dfa-to-regex":
        return this.dfaToRegex(automaton)
      case "nfa-to-regex":
        return this.nfaToRegex(automaton)
      case "regex-to-enfa":
        return this.regexToEnfa(automaton)
      case "regex-to-dfa":
        return this.regexToDfa(automaton)
      case "dfa-minimize":
        return this.minimizeDfa(automaton)
      case "nfa-to-enfa":
        return this.nfaToEnfa(automaton)
      default:
        return []
    }
  }

  private async nfaToDfa(nfa: Automaton): Promise<ConversionStep[]> {
    const steps: ConversionStep[] = []
    const dfaStates: string[] = []
    const dfaTransitions: Transition[] = []
    const dfaFinalStates: string[] = []
    const stateQueue: string[][] = []
    const processedStates = new Set<string>()

    const initialStateSet = [nfa.startState]
    const initialStateName = `{${initialStateSet.join(",")}}`
    dfaStates.push(initialStateName)
    stateQueue.push(initialStateSet)

    if (initialStateSet.some((state) => nfa.finalStates.includes(state))) {
      dfaFinalStates.push(initialStateName)
    }

    steps.push({
      automaton: {
        ...nfa,
        type: "dfa",
        states: [initialStateName],
        transitions: [],
        finalStates: dfaFinalStates.slice(),
        startState: initialStateName,
      },
      description: "Step 1: Start conversion - Create initial DFA state",
      explanation: `Step 1: We begin the NFA to DFA conversion by creating the initial DFA state ${initialStateName} from the NFA start state ${nfa.startState}. This state represents the set of NFA states we can be in initially.`,
      highlightedStates: [initialStateName],
      highlightedTransitions: [],
    })

    let stepNumber = 2
    while (stateQueue.length > 0) {
      const currentStateSet = stateQueue.shift()!
      const currentStateName = `{${currentStateSet.join(",")}}`

      if (processedStates.has(currentStateName)) continue
      processedStates.add(currentStateName)

      for (const symbol of nfa.alphabet) {
        const nextStateSet = new Set<string>()

        for (const state of currentStateSet) {
          const transitions = nfa.transitions.filter((t) => t.from === state && t.symbol === symbol)
          transitions.forEach((t) => nextStateSet.add(t.to))
        }

        if (nextStateSet.size > 0) {
          const nextStateArray = Array.from(nextStateSet).sort()
          const nextStateName = `{${nextStateArray.join(",")}}`

          dfaTransitions.push({
            from: currentStateName,
            to: nextStateName,
            symbol,
          })

          if (!dfaStates.includes(nextStateName)) {
            dfaStates.push(nextStateName)
            stateQueue.push(nextStateArray)

            if (nextStateArray.some((state) => nfa.finalStates.includes(state))) {
              dfaFinalStates.push(nextStateName)
            }
          }

          steps.push({
            automaton: {
              ...nfa,
              type: "dfa",
              states: dfaStates.slice(),
              transitions: dfaTransitions.slice(),
              finalStates: dfaFinalStates.slice(),
              startState: initialStateName,
            },
            description: `Step ${stepNumber}: Process ${currentStateName} with input '${symbol}'`,
            explanation: `Step ${stepNumber}: From DFA state ${currentStateName} (representing NFA states {${currentStateSet.join(", ")}}) with input symbol '${symbol}', we can reach NFA states {${nextStateArray.join(", ")}}. This creates ${dfaStates.includes(nextStateName) ? "existing" : "new"} DFA state ${nextStateName}. ${nextStateArray.some((state) => nfa.finalStates.includes(state)) ? "This is a final state because it contains final states from the original NFA." : "This is not a final state."}`,
            highlightedStates: [currentStateName, nextStateName],
            highlightedTransitions: [{ from: currentStateName, to: nextStateName, symbol }],
            newStates: dfaStates.includes(nextStateName) ? [] : [nextStateName],
          })

          stepNumber++
        }
      }
    }

    steps.push({
      automaton: {
        ...nfa,
        type: "dfa",
        states: dfaStates.slice(),
        transitions: dfaTransitions.slice(),
        finalStates: dfaFinalStates.slice(),
        startState: initialStateName,
      },
      description: `Step ${stepNumber}: Conversion Complete - Final DFA`,
      explanation: `Step ${stepNumber}: NFA to DFA conversion is now complete! The final DFA has ${dfaStates.length} states, ${dfaTransitions.length} transitions, and ${dfaFinalStates.length} final states. Each DFA state represents a set of possible NFA states, making the automaton deterministic.`,
      highlightedStates: dfaStates,
      highlightedTransitions: dfaTransitions,
    })

    return steps
  }

  private async enfaToNfa(enfa: Automaton): Promise<ConversionStep[]> {
    const steps: ConversionStep[] = []
    const nfaTransitions: Transition[] = []

    // Ensure alphabet has epsilon symbol properly
    const cleanAlphabet = enfa.alphabet.map((s) => (s === "epsilon" ? "ε" : s))
    const hasEpsilon = cleanAlphabet.includes("ε")

    steps.push({
      automaton: {
        ...enfa,
        type: "nfa",
        alphabet: cleanAlphabet,
        transitions: [],
      },
      description: "Step 1: Start conversion - Analyze ε-transitions",
      explanation: `Step 1: We begin ε-NFA to NFA conversion by identifying all ε-transitions in the automaton. These transitions allow movement between states without consuming input symbols and need to be eliminated.`,
      highlightedStates: enfa.states,
      highlightedTransitions: enfa.transitions.filter((t) => t.symbol === "ε" || t.symbol === "epsilon"),
    })

    const epsilonClosures = new Map<string, Set<string>>()
    for (const state of enfa.states) {
      epsilonClosures.set(state, this.computeEpsilonClosure(enfa, state))
    }

    steps.push({
      automaton: {
        ...enfa,
        type: "nfa",
        alphabet: cleanAlphabet,
        transitions: [],
      },
      description: "Step 2: Compute ε-closures for all states",
      explanation: `Step 2: Computing ε-closure for each state. ε-closure(q) includes state q and all states reachable from q using only ε-transitions. Results: ${Array.from(
        epsilonClosures.entries(),
      )
        .map(([state, closure]) => `ε-closure(${state}) = {${Array.from(closure).sort().join(", ")}}`)
        .join("; ")}`,
      highlightedStates: enfa.states,
      highlightedTransitions: enfa.transitions.filter((t) => t.symbol === "ε" || t.symbol === "epsilon"),
    })

    for (const state of enfa.states) {
      const closure = epsilonClosures.get(state)!

      for (const symbol of cleanAlphabet.filter((s) => s !== "ε")) {
        const reachableStates = new Set<string>()

        for (const closureState of closure) {
          const transitions = enfa.transitions.filter((t) => t.from === closureState && t.symbol === symbol)
          for (const transition of transitions) {
            const destClosure = epsilonClosures.get(transition.to)!
            destClosure.forEach((s) => reachableStates.add(s))
          }
        }

        for (const reachableState of reachableStates) {
          nfaTransitions.push({
            from: state,
            to: reachableState,
            symbol,
          })
        }
      }
    }

    // Sort transitions for better display
    nfaTransitions.sort((a, b) => {
      if (a.from !== b.from) return a.from.localeCompare(b.from)
      if (a.symbol !== b.symbol) return a.symbol.localeCompare(b.symbol)
      return a.to.localeCompare(b.to)
    })

    steps.push({
      automaton: {
        ...enfa,
        type: "nfa",
        transitions: nfaTransitions,
        alphabet: cleanAlphabet.filter((s) => s !== "ε"),
      },
      description: "Step 3: Create NFA transitions - Eliminate ε-transitions",
      explanation:
        "Step 3: For each state and input symbol, we create direct transitions to all states reachable through the combination of that symbol and ε-transitions. This eliminates all ε-transitions while preserving the language.",
      highlightedStates: [],
      highlightedTransitions: nfaTransitions,
    })

    steps.push({
      automaton: {
        ...enfa,
        type: "nfa",
        transitions: nfaTransitions,
        alphabet: cleanAlphabet.filter((s) => s !== "ε"),
      },
      description: "Step 4: Conversion Complete - Final NFA",
      explanation: `Step 4: ε-NFA to NFA conversion is complete! The resulting NFA has no ε-transitions and accepts the same language as the original ε-NFA. All ε-transitions have been replaced with direct transitions.`,
      highlightedStates: enfa.states,
      highlightedTransitions: nfaTransitions,
    })

    return steps
  }

  private async enfaToDfa(enfa: Automaton): Promise<ConversionStep[]> {
    const enfaToNfaSteps = await this.enfaToNfa(enfa)
    const nfa = enfaToNfaSteps[enfaToNfaSteps.length - 1].automaton
    const nfaToDfaSteps = await this.nfaToDfa(nfa)

    const allSteps = [...enfaToNfaSteps, ...nfaToDfaSteps]
    return allSteps.map((step, index) => ({
      ...step,
      description: step.description.replace(/Step \d+/, `Step ${index + 1}`),
      explanation: step.explanation.replace(/Step \d+/, `Step ${index + 1}`),
    }))
  }

  private async dfaToNfa(dfa: Automaton): Promise<ConversionStep[]> {
    const steps: ConversionStep[] = []

    steps.push({
      automaton: {
        ...dfa,
        type: "nfa",
      },
      description: "Step 1: Convert DFA to NFA - Trivial conversion",
      explanation:
        "Step 1: Every DFA is already an NFA by definition. This conversion is trivial - we simply change the type designation. All transitions remain deterministic, which is a special case of non-deterministic behavior.",
      highlightedStates: dfa.states,
      highlightedTransitions: dfa.transitions,
    })

    steps.push({
      automaton: {
        ...dfa,
        type: "nfa",
      },
      description: "Step 2: Conversion Complete - Final NFA",
      explanation:
        "Step 2: Conversion complete! The resulting NFA is identical to the original DFA since every DFA is a valid NFA. No structural changes were needed.",
      highlightedStates: dfa.states,
      highlightedTransitions: dfa.transitions,
    })

    return steps
  }

  private async dfaToRegex(dfa: Automaton): Promise<ConversionStep[]> {
    const steps: ConversionStep[] = []
    let currentStates = [...dfa.states]
    let currentTransitions = [...dfa.transitions]

    const newStart = "qstart"
    const newFinal = "qfinal"

    currentStates.push(newStart, newFinal)
    currentTransitions.push({ from: newStart, to: dfa.startState, symbol: "ε" })

    for (const finalState of dfa.finalStates) {
      currentTransitions.push({ from: finalState, to: newFinal, symbol: "ε" })
    }

    steps.push({
      automaton: {
        ...dfa,
        states: currentStates.slice(),
        transitions: currentTransitions.slice(),
        startState: newStart,
        finalStates: [newFinal],
      },
      description: "Step 1: Prepare for state elimination - Add new start/final states",
      explanation: `Step 1: We add new start state ${newStart} connected to original start ${dfa.startState} with ε-transition, and new final state ${newFinal} connected from all original final states. This standardizes the automaton for state elimination.`,
      highlightedStates: [newStart, newFinal],
      highlightedTransitions: currentTransitions.filter((t) => t.from === newStart || t.to === newFinal),
    })

    const statesToEliminate = dfa.states.filter((s) => s !== dfa.startState && !dfa.finalStates.includes(s))
    let stepNumber = 2

    for (const stateToEliminate of statesToEliminate.slice(0, Math.min(3, statesToEliminate.length))) {
      currentStates = currentStates.filter((s) => s !== stateToEliminate)

      const incomingTransitions = currentTransitions.filter((t) => t.to === stateToEliminate)
      const outgoingTransitions = currentTransitions.filter((t) => t.from === stateToEliminate)
      const selfLoop = currentTransitions.find((t) => t.from === stateToEliminate && t.to === stateToEliminate)

      currentTransitions = currentTransitions.filter((t) => t.from !== stateToEliminate && t.to !== stateToEliminate)

      for (const incoming of incomingTransitions) {
        for (const outgoing of outgoingTransitions) {
          let newSymbol = incoming.symbol
          if (selfLoop) {
            newSymbol += `(${selfLoop.symbol})*`
          }
          newSymbol += outgoing.symbol

          currentTransitions.push({
            from: incoming.from,
            to: outgoing.to,
            symbol: newSymbol,
          })
        }
      }

      steps.push({
        automaton: {
          ...dfa,
          states: currentStates.slice(),
          transitions: currentTransitions.slice(),
          startState: newStart,
          finalStates: [newFinal],
        },
        description: `Step ${stepNumber}: Eliminate state ${stateToEliminate}`,
        explanation: `Step ${stepNumber}: Eliminating state ${stateToEliminate} by creating new transitions that bypass it. We combine incoming and outgoing transitions, adding Kleene star for self-loops. This preserves the language while reducing states.`,
        highlightedStates: [],
        highlightedTransitions: currentTransitions.filter((t) => t.symbol.includes("*") || t.symbol.length > 1),
        removedStates: [stateToEliminate],
      })

      stepNumber++
    }

    const finalTransition = currentTransitions.find((t) => t.from === newStart && t.to === newFinal)
    const regex = finalTransition ? finalTransition.symbol : "∅"

    steps.push({
      automaton: {
        ...dfa,
        type: "regex",
        regex: regex,
        states: [newStart, newFinal],
        transitions: finalTransition ? [finalTransition] : [],
        startState: newStart,
        finalStates: [newFinal],
      },
      description: `Step ${stepNumber}: Conversion Complete - Extract final regular expression`,
      explanation: `Step ${stepNumber}: State elimination complete! The final regular expression is: ${regex}. This regex accepts exactly the same language as the original DFA.`,
      highlightedStates: [newStart, newFinal],
      highlightedTransitions: finalTransition ? [finalTransition] : [],
      regexStep: regex,
    })

    return steps
  }

  private async nfaToRegex(nfa: Automaton): Promise<ConversionStep[]> {
    const nfaToDfaSteps = await this.nfaToDfa(nfa)
    const dfa = nfaToDfaSteps[nfaToDfaSteps.length - 1].automaton
    const dfaToRegexSteps = await this.dfaToRegex(dfa)

    const allSteps = [...nfaToDfaSteps, ...dfaToRegexSteps]
    return allSteps.map((step, index) => ({
      ...step,
      description: step.description.replace(/Step \d+/, `Step ${index + 1}`),
      explanation: step.explanation.replace(/Step \d+/, `Step ${index + 1}`),
    }))
  }

  private async regexToEnfa(automaton: Automaton): Promise<ConversionStep[]> {
    const steps: ConversionStep[] = []
    const regex = automaton.regex || "a*b"

    let stateCounter = 0
    const newState = () => `q${stateCounter++}`

    const enfaStates: string[] = []
    const enfaTransitions: Transition[] = []

    steps.push({
      automaton: {
        type: "enfa",
        name: `ε-NFA for ${regex}`,
        states: [],
        alphabet: [],
        startState: "",
        finalStates: [],
        transitions: [],
        regex: regex,
      },
      description: "Step 1: Start conversion - Analyze regular expression",
      explanation: `Step 1: We begin converting regular expression "${regex}" to ε-NFA using Thompson's construction. This method builds the automaton compositionally based on regex operators.`,
      highlightedStates: [],
      highlightedTransitions: [],
      regexStep: regex,
    })

    if (regex.includes("*")) {
      const start = newState()
      const middle = newState()
      const end = newState()

      enfaStates.push(start, middle, end)

      const baseSymbol = regex.replace("*", "")
      enfaTransitions.push(
        { from: start, to: middle, symbol: "ε" },
        { from: start, to: end, symbol: "ε" },
        { from: middle, to: middle, symbol: baseSymbol },
        { from: middle, to: end, symbol: "ε" },
      )

      steps.push({
        automaton: {
          type: "enfa",
          name: `ε-NFA for ${regex}`,
          states: enfaStates,
          alphabet: [baseSymbol, "ε"],
          startState: start,
          finalStates: [end],
          transitions: enfaTransitions,
          regex: regex,
        },
        description: "Step 2: Apply Thompson's construction for Kleene star",
        explanation: `Step 2: For Kleene star pattern "${regex}", we create three states with ε-transitions. The start state can go directly to end (zero repetitions) or to middle state for one or more repetitions.`,
        highlightedStates: enfaStates,
        highlightedTransitions: enfaTransitions,
        regexStep: regex,
      })
    } else {
      const start = newState()
      const end = newState()

      enfaStates.push(start, end)
      enfaTransitions.push({ from: start, to: end, symbol: regex })

      steps.push({
        automaton: {
          type: "enfa",
          name: `ε-NFA for ${regex}`,
          states: enfaStates,
          alphabet: [regex, "ε"],
          startState: start,
          finalStates: [end],
          transitions: enfaTransitions,
          regex: regex,
        },
        description: "Step 2: Create simple ε-NFA for basic symbol",
        explanation: `Step 2: For simple symbol "${regex}", we create a basic ε-NFA with two states connected by a single transition labeled with the symbol.`,
        highlightedStates: enfaStates,
        highlightedTransitions: enfaTransitions,
        regexStep: regex,
      })
    }

    steps.push({
      automaton: {
        type: "enfa",
        name: `ε-NFA for ${regex}`,
        states: enfaStates,
        alphabet: enfaStates.length > 2 ? [regex.replace("*", ""), "ε"] : [regex, "ε"],
        startState: enfaStates[0],
        finalStates: [enfaStates[enfaStates.length - 1]],
        transitions: enfaTransitions,
        regex: regex,
      },
      description: "Step 3: Conversion Complete - Final ε-NFA",
      explanation: `Step 3: Regular expression to ε-NFA conversion complete! The resulting ε-NFA accepts exactly the language defined by regex "${regex}".`,
      highlightedStates: enfaStates,
      highlightedTransitions: enfaTransitions,
      regexStep: regex,
    })

    return steps
  }

  private async regexToDfa(automaton: Automaton): Promise<ConversionStep[]> {
    const regexToEnfaSteps = await this.regexToEnfa(automaton)
    const enfa = regexToEnfaSteps[regexToEnfaSteps.length - 1].automaton
    const enfaToDfaSteps = await this.enfaToDfa(enfa)

    const allSteps = [...regexToEnfaSteps, ...enfaToDfaSteps]
    return allSteps.map((step, index) => ({
      ...step,
      description: step.description.replace(/Step \d+/, `Step ${index + 1}`),
      explanation: step.explanation.replace(/Step \d+/, `Step ${index + 1}`),
    }))
  }

  private async minimizeDfa(dfa: Automaton): Promise<ConversionStep[]> {
    const steps: ConversionStep[] = []

    steps.push({
      automaton: dfa,
      description: "Step 1: Start DFA minimization - Analyze current DFA",
      explanation: `Step 1: We begin DFA minimization by analyzing the current DFA structure. The goal is to find and merge equivalent states while removing unreachable states to create the minimal DFA.`,
      highlightedStates: dfa.states,
      highlightedTransitions: dfa.transitions,
    })

    const reachableStates = this.findReachableStates(dfa)
    const unreachableStates = dfa.states.filter((s) => !reachableStates.has(s))

    if (unreachableStates.length > 0) {
      const newStates = dfa.states.filter((s) => reachableStates.has(s))
      const newTransitions = dfa.transitions.filter((t) => reachableStates.has(t.from) && reachableStates.has(t.to))

      steps.push({
        automaton: {
          ...dfa,
          states: newStates,
          transitions: newTransitions,
          finalStates: dfa.finalStates.filter((s) => reachableStates.has(s)),
        },
        description: "Step 2: Remove unreachable states",
        explanation: `Step 2: Found and removed unreachable states: {${unreachableStates.join(", ")}}. These states cannot be reached from the start state and can be safely removed without changing the accepted language.`,
        highlightedStates: Array.from(reachableStates),
        highlightedTransitions: newTransitions,
        removedStates: unreachableStates,
      })
    } else {
      steps.push({
        automaton: dfa,
        description: "Step 2: Check for unreachable states - None found",
        explanation:
          "Step 2: All states are reachable from the start state. No states need to be removed in this phase.",
        highlightedStates: dfa.states,
        highlightedTransitions: dfa.transitions,
      })
    }

    const currentStates = dfa.states.filter((s) => reachableStates.has(s))
    const equivalentStates = this.findEquivalentStates(dfa, currentStates)

    if (equivalentStates.length > 0) {
      const stateMapping = new Map<string, string>()
      const newStates: string[] = []

      for (const group of equivalentStates) {
        const representative = group[0]
        newStates.push(representative)
        for (const state of group) {
          stateMapping.set(state, representative)
        }
      }

      for (const state of currentStates) {
        if (!stateMapping.has(state)) {
          newStates.push(state)
          stateMapping.set(state, state)
        }
      }

      const newTransitions: Transition[] = []
      const addedTransitions = new Set<string>()

      for (const transition of dfa.transitions) {
        const newFrom = stateMapping.get(transition.from)
        const newTo = stateMapping.get(transition.to)

        if (newFrom && newTo) {
          const transitionKey = `${newFrom}-${transition.symbol}-${newTo}`
          if (!addedTransitions.has(transitionKey)) {
            newTransitions.push({
              from: newFrom,
              to: newTo,
              symbol: transition.symbol,
            })
            addedTransitions.add(transitionKey)
          }
        }
      }

      steps.push({
        automaton: {
          ...dfa,
          type: "minimized-dfa",
          states: newStates,
          transitions: newTransitions,
          startState: stateMapping.get(dfa.startState) || dfa.startState,
          finalStates: dfa.finalStates.map((s) => stateMapping.get(s)).filter((s) => s) as string[],
          equivalentStates: equivalentStates,
        },
        description: "Step 3: Merge equivalent states",
        explanation: `Step 3: Found and merged equivalent states: ${equivalentStates.map((group) => `{${group.join(", ")}}`).join(", ")}. These states have identical behavior for all possible input strings.`,
        highlightedStates: newStates,
        highlightedTransitions: newTransitions,
      })
    } else {
      steps.push({
        automaton: {
          ...dfa,
          type: "minimized-dfa",
        },
        description: "Step 3: Check for equivalent states - None found",
        explanation: "Step 3: No equivalent states found. All remaining states have unique behaviors.",
        highlightedStates: currentStates,
        highlightedTransitions: dfa.transitions,
      })
    }

    const finalAutomaton = steps[steps.length - 1].automaton
    steps.push({
      automaton: {
        ...finalAutomaton,
        type: "minimized-dfa",
      },
      description: "Step 4: Minimization Complete - Final minimal DFA",
      explanation: `Step 4: DFA minimization complete! The minimal DFA has ${finalAutomaton.states.length} states and accepts the same language as the original DFA with the minimum number of states possible.`,
      highlightedStates: finalAutomaton.states,
      highlightedTransitions: finalAutomaton.transitions,
    })

    return steps
  }

  private async nfaToEnfa(nfa: Automaton): Promise<ConversionStep[]> {
    const steps: ConversionStep[] = []

    steps.push({
      automaton: nfa,
      description: "Step 1: Start conversion - Analyze NFA structure",
      explanation:
        "Step 1: We begin converting NFA to ε-NFA by analyzing the current structure. We'll add ε-transitions to demonstrate how NFAs can be extended with epsilon transitions.",
      highlightedStates: nfa.states,
      highlightedTransitions: nfa.transitions,
    })

    const newTransitions = [...nfa.transitions]
    const newStates = [...nfa.states]
    const intermediateState = `q_ε`
    newStates.push(intermediateState)

    newTransitions.push({
      from: nfa.startState,
      to: intermediateState,
      symbol: "ε", // Ensure proper epsilon symbol
    })

    if (nfa.finalStates.length > 0) {
      newTransitions.push({
        from: intermediateState,
        to: nfa.finalStates[0],
        symbol: "ε", // Ensure proper epsilon symbol
      })
    }

    // Sort alphabet with epsilon at the end
    const newAlphabet = [...nfa.alphabet, "ε"].sort((a, b) => {
      if (a === "ε") return 1
      if (b === "ε") return -1
      return a.localeCompare(b)
    })

    steps.push({
      automaton: {
        ...nfa,
        type: "enfa",
        states: newStates,
        transitions: newTransitions,
        alphabet: newAlphabet,
      },
      description: "Step 2: Add ε-transitions and intermediate state",
      explanation: `Step 2: Added intermediate state ${intermediateState} with ε-transitions. This creates an equivalent ε-NFA that accepts the same language but uses epsilon transitions for more flexible state movement.`,
      highlightedStates: [intermediateState],
      highlightedTransitions: newTransitions.filter((t) => t.symbol === "ε"),
      newStates: [intermediateState],
    })

    steps.push({
      automaton: {
        ...nfa,
        type: "enfa",
        states: newStates,
        transitions: newTransitions,
        alphabet: newAlphabet,
      },
      description: "Step 3: Conversion Complete - Final ε-NFA",
      explanation:
        "Step 3: NFA to ε-NFA conversion complete! The resulting ε-NFA accepts the same language as the original NFA but now includes epsilon transitions for more flexible state transitions.",
      highlightedStates: newStates,
      highlightedTransitions: newTransitions,
    })

    return steps
  }

  private computeEpsilonClosure(automaton: Automaton, state: string): Set<string> {
    const closure = new Set<string>()
    const stack = [state]

    while (stack.length > 0) {
      const current = stack.pop()!
      if (closure.has(current)) continue

      closure.add(current)

      const epsilonTransitions = automaton.transitions.filter(
        (t) => t.from === current && (t.symbol === "ε" || t.symbol === "epsilon"),
      )

      for (const transition of epsilonTransitions) {
        if (!closure.has(transition.to)) {
          stack.push(transition.to)
        }
      }
    }

    return closure
  }

  private findReachableStates(automaton: Automaton): Set<string> {
    const reachable = new Set<string>()
    const queue = [automaton.startState]

    while (queue.length > 0) {
      const current = queue.shift()!
      if (reachable.has(current)) continue

      reachable.add(current)

      const outgoingTransitions = automaton.transitions.filter((t) => t.from === current)
      for (const transition of outgoingTransitions) {
        if (!reachable.has(transition.to)) {
          queue.push(transition.to)
        }
      }
    }

    return reachable
  }

  private findEquivalentStates(automaton: Automaton, states: string[]): string[][] {
    const equivalentGroups: string[][] = []
    const processed = new Set<string>()

    for (let i = 0; i < states.length; i++) {
      if (processed.has(states[i])) continue

      const group = [states[i]]
      processed.add(states[i])

      for (let j = i + 1; j < states.length; j++) {
        if (processed.has(states[j])) continue

        if (this.areStatesEquivalent(automaton, states[i], states[j])) {
          group.push(states[j])
          processed.add(states[j])
        }
      }

      if (group.length > 1) {
        equivalentGroups.push(group)
      }
    }

    return equivalentGroups
  }

  private areStatesEquivalent(automaton: Automaton, state1: string, state2: string): boolean {
    const isFinal1 = automaton.finalStates.includes(state1)
    const isFinal2 = automaton.finalStates.includes(state2)

    if (isFinal1 !== isFinal2) return false

    for (const symbol of automaton.alphabet) {
      const transitions1 = automaton.transitions.filter((t) => t.from === state1 && t.symbol === symbol)
      const transitions2 = automaton.transitions.filter((t) => t.from === state2 && t.symbol === symbol)

      if (transitions1.length !== transitions2.length) return false

      if (transitions1.length === 1 && transitions2.length === 1) {
        if (transitions1[0].to !== transitions2[0].to) return false
      }
    }

    return true
  }
}
