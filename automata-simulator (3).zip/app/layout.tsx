import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "Automata Conversion Simulator",
  description: "Interactive Multi-Mode Automata Conversion Simulator with Step-by-Step Visualization",
  keywords: ["automata", "finite automata", "NFA", "DFA", "regular expressions", "computer science"],
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
