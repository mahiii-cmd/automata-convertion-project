"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, SkipForward, SkipBack, RotateCcw } from "lucide-react"
import { AutomataConverter } from "../components/automata-converter"
import { InteractiveDiagram } from "../components/interactive-diagram"
import { TransitionTable } from "../components/transition-table"
import { predefinedProblems } from "../data/problems"
import type { Automaton, ConversionMode, ConversionStep } from "../types/automata"

const conversionModes: { value: ConversionMode; label: string; description: string }[] = [
  {
    value: "nfa-to-dfa",
    label: "NFA → DFA",
    description: "Convert Non-deterministic to Deterministic Finite Automaton",
  },
  { value: "enfa-to-nfa", label: "ε-NFA → NFA", description: "Remove epsilon transitions from NFA" },
  { value: "enfa-to-dfa", label: "ε-NFA → DFA", description: "Convert epsilon-NFA directly to DFA" },
  { value: "dfa-to-nfa", label: "DFA → NFA", description: "Convert DFA to NFA (trivial conversion)" },
  { value: "dfa-to-regex", label: "DFA → RegEx", description: "Convert DFA to Regular Expression" },
  { value: "nfa-to-regex", label: "NFA → RegEx", description: "Convert NFA to Regular Expression" },
  { value: "regex-to-enfa", label: "RegEx → ε-NFA", description: "Convert Regular Expression to epsilon-NFA" },
  { value: "regex-to-dfa", label: "RegEx → DFA", description: "Convert Regular Expression to DFA" },
  { value: "dfa-minimize", label: "DFA Minimize", description: "Minimize DFA by removing equivalent states" },
  { value: "nfa-to-enfa", label: "NFA → ε-NFA", description: "Add epsilon transitions to NFA" },
]

export default function AutomataSimulator() {
  const [mode, setMode] = useState<ConversionMode>("nfa-to-dfa")
  const [selectedProblem, setSelectedProblem] = useState<string>("")
  const [originalAutomaton, setOriginalAutomaton] = useState<Automaton | null>(null)
  const [conversionSteps, setConversionSteps] = useState<ConversionStep[]>([])
  const [currentStep, setCurrentStep] = useState(0)
  const [isConverting, setIsConverting] = useState(false)
  const [autoPlay, setAutoPlay] = useState(false)

  const converter = new AutomataConverter()

  useEffect(() => {
    if (selectedProblem && predefinedProblems[selectedProblem]) {
      setOriginalAutomaton(predefinedProblems[selectedProblem])
      setConversionSteps([])
      setCurrentStep(0)
      setIsConverting(false)
    }
  }, [selectedProblem])

  useEffect(() => {
    let interval: NodeJS.Timeout
    if (autoPlay && currentStep < conversionSteps.length - 1) {
      interval = setInterval(() => {
        setCurrentStep((prev) => prev + 1)
      }, 2000)
    } else if (autoPlay && currentStep >= conversionSteps.length - 1) {
      setAutoPlay(false)
    }
    return () => clearInterval(interval)
  }, [autoPlay, currentStep, conversionSteps.length])

  const handleConvert = async () => {
    if (!originalAutomaton) return

    setIsConverting(true)
    const steps = await converter.convert(originalAutomaton, mode)
    setConversionSteps(steps)
    setCurrentStep(0)
    setIsConverting(false)
  }

  const handleReset = () => {
    setConversionSteps([])
    setCurrentStep(0)
    setAutoPlay(false)
    setIsConverting(false)
  }

  const currentAutomaton =
    conversionSteps.length > 0 ? conversionSteps[currentStep]?.automaton || originalAutomaton : originalAutomaton

  const getAvailableProblems = () => {
    return Object.keys(predefinedProblems).filter((key) => {
      const problem = predefinedProblems[key]
      if (mode === "nfa-to-dfa" || mode === "nfa-to-regex" || mode === "nfa-to-enfa") return problem.type === "nfa"
      if (mode === "enfa-to-nfa" || mode === "enfa-to-dfa") return problem.type === "enfa"
      if (mode === "dfa-to-nfa" || mode === "dfa-to-regex" || mode === "dfa-minimize") return problem.type === "dfa"
      if (mode === "regex-to-enfa" || mode === "regex-to-dfa") return problem.type === "regex"
      return true
    })
  }

  const selectedModeInfo = conversionModes.find((m) => m.value === mode)

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-center bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Advanced Multi-Mode Automata Conversion Simulator
            </CardTitle>
            <p className="text-center text-muted-foreground">
              Interactive step-by-step automata conversion with 10 different modes, live diagrams and transition tables
            </p>
          </CardHeader>
        </Card>

        {/* Mode Overview */}
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-5 gap-2 mb-4">
              {conversionModes.map((modeInfo) => (
                <Button
                  key={modeInfo.value}
                  variant={mode === modeInfo.value ? "default" : "outline"}
                  size="sm"
                  onClick={() => {
                    setMode(modeInfo.value)
                    setSelectedProblem("")
                    handleReset()
                  }}
                  className="text-xs"
                >
                  {modeInfo.label}
                </Button>
              ))}
            </div>
            {selectedModeInfo && (
              <div className="text-sm text-muted-foreground text-center p-2 bg-muted rounded">
                {selectedModeInfo.description}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Controls */}
        <Card>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">Conversion Mode</label>
                <Select
                  value={mode}
                  onValueChange={(value: ConversionMode) => {
                    setMode(value)
                    setSelectedProblem("")
                    handleReset()
                  }}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {conversionModes.map((modeInfo) => (
                      <SelectItem key={modeInfo.value} value={modeInfo.value}>
                        {modeInfo.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Select Problem</label>
                <Select value={selectedProblem} onValueChange={setSelectedProblem}>
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a problem" />
                  </SelectTrigger>
                  <SelectContent>
                    {getAvailableProblems().map((key) => (
                      <SelectItem key={key} value={key}>
                        {predefinedProblems[key].name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-end gap-2">
                <Button onClick={handleConvert} disabled={!originalAutomaton || isConverting} className="flex-1">
                  {isConverting ? "Converting..." : "Convert"}
                </Button>
                <Button onClick={handleReset} variant="outline">
                  <RotateCcw className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Step Controls */}
            {conversionSteps.length > 0 && (
              <div className="flex items-center justify-center gap-4 p-4 bg-muted rounded-lg">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                  disabled={currentStep === 0}
                >
                  <SkipBack className="w-4 h-4" />
                </Button>

                <Button variant="outline" size="sm" onClick={() => setAutoPlay(!autoPlay)}>
                  {autoPlay ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                </Button>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentStep(Math.min(conversionSteps.length - 1, currentStep + 1))}
                  disabled={currentStep === conversionSteps.length - 1}
                >
                  <SkipForward className="w-4 h-4" />
                </Button>

                <Badge variant="secondary">
                  Step {currentStep + 1} of {conversionSteps.length}
                </Badge>
              </div>
            )}
            {conversionSteps.length > 0 && (
              <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                <div
                  className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${((currentStep + 1) / conversionSteps.length) * 100}%` }}
                ></div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Diagram */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>
                  {conversionSteps.length === 0
                    ? "Original Automaton"
                    : `${selectedModeInfo?.label} - Step ${currentStep + 1}`}
                </span>
                {currentAutomaton && (
                  <div className="flex gap-2">
                    <Badge
                      variant={
                        currentAutomaton.type === "dfa"
                          ? "default"
                          : currentAutomaton.type === "minimized-dfa"
                            ? "destructive"
                            : currentAutomaton.type === "regex"
                              ? "secondary"
                              : "outline"
                      }
                    >
                      {currentAutomaton.type.toUpperCase().replace("-", " ")}
                    </Badge>
                    {currentAutomaton.regex && <Badge variant="secondary">RegEx: {currentAutomaton.regex}</Badge>}
                  </div>
                )}
              </CardTitle>
              {conversionSteps.length > 0 && conversionSteps[currentStep]?.description && (
                <p className="text-sm text-muted-foreground">{conversionSteps[currentStep].description}</p>
              )}
            </CardHeader>
            <CardContent>
              {currentAutomaton ? (
                <InteractiveDiagram
                  automaton={currentAutomaton}
                  highlightedStates={conversionSteps[currentStep]?.highlightedStates || []}
                  highlightedTransitions={conversionSteps[currentStep]?.highlightedTransitions || []}
                />
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">
                  Select a problem to view the automaton
                </div>
              )}
            </CardContent>
          </Card>

          {/* Transition Table */}
          <Card>
            <CardHeader>
              <CardTitle>{currentAutomaton?.type === "regex" ? "Regular Expression" : "Transition Table"}</CardTitle>
            </CardHeader>
            <CardContent>
              {currentAutomaton ? (
                currentAutomaton.type === "regex" ? (
                  <div className="space-y-4">
                    <div className="text-center p-8 bg-muted rounded-lg">
                      <div className="text-2xl font-mono font-bold text-blue-600">
                        {currentAutomaton.regex || "No regex available"}
                      </div>
                    </div>
                    <div className="text-sm text-muted-foreground">
                      <div className="font-medium mb-2">Regular Expression Notation:</div>
                      <div>• * = Kleene star (zero or more)</div>
                      <div>• + = One or more</div>
                      <div>• | = Union (OR)</div>
                      <div>• () = Grouping</div>
                      <div>• ε = Empty string</div>
                    </div>
                  </div>
                ) : (
                  <TransitionTable
                    automaton={currentAutomaton}
                    highlightedStates={conversionSteps[currentStep]?.highlightedStates || []}
                  />
                )
              ) : (
                <div className="h-64 flex items-center justify-center text-muted-foreground">No automaton selected</div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Step Information */}
        {conversionSteps.length > 0 && conversionSteps[currentStep]?.explanation && (
          <Card>
            <CardHeader>
              <CardTitle>Step {currentStep + 1} Explanation</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm leading-relaxed">{conversionSteps[currentStep].explanation}</p>
              {conversionSteps[currentStep]?.regexStep && (
                <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                  <div className="font-medium text-blue-800 mb-1">Regular Expression:</div>
                  <div className="font-mono text-blue-600">{conversionSteps[currentStep].regexStep}</div>
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* Conversion Statistics */}
        {conversionSteps.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle>Conversion Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-600">{conversionSteps.length}</div>
                  <div className="text-sm text-muted-foreground">Total Steps</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">{currentAutomaton?.states.length || 0}</div>
                  <div className="text-sm text-muted-foreground">Final States</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">{currentAutomaton?.transitions.length || 0}</div>
                  <div className="text-sm text-muted-foreground">Transitions</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-orange-600">{currentAutomaton?.alphabet.length || 0}</div>
                  <div className="text-sm text-muted-foreground">Alphabet Size</div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
