export type AutomatonType = "nfa" | "dfa" | "enfa" | "regex" | "minimized-dfa"
export type ConversionMode =
  | "nfa-to-dfa"
  | "enfa-to-nfa"
  | "enfa-to-dfa"
  | "dfa-to-nfa"
  | "dfa-to-regex"
  | "nfa-to-regex"
  | "regex-to-enfa"
  | "regex-to-dfa"
  | "dfa-minimize"
  | "nfa-to-enfa"

export interface Transition {
  from: string
  to: string
  symbol: string
}

export interface Automaton {
  type: AutomatonType
  name: string
  states: string[]
  alphabet: string[]
  startState: string
  finalStates: string[]
  transitions: Transition[]
  regex?: string
  equivalentStates?: string[][]
}

export interface ConversionStep {
  automaton: Automaton
  description: string
  explanation: string
  highlightedStates: string[]
  highlightedTransitions: Transition[]
  newStates?: string[]
  removedStates?: string[]
  regexStep?: string
}
