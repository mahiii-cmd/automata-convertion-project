# Automata Conversion Simulator

A comprehensive, interactive educational tool for learning automata theory with step-by-step visualizations and 10 different conversion modes.

## Features

🔄 **10 Conversion Modes:**
- NFA → DFA
- ε-NFA → NFA  
- ε-NFA → DFA
- DFA → NFA
- DFA → RegEx
- NFA → RegEx
- RegEx → ε-NFA
- RegEx → DFA
- DFA Minimization
- NFA → ε-NFA

📚 **25 Predefined Problems:**
- 5 problems for each automaton type
- Ranging from simple to complex examples
- Educational progression from basic to advanced

🎯 **Interactive Features:**
- Step-by-step conversion visualization
- Interactive diagrams with clickable states
- Real-time transition tables
- Auto-play mode with customizable timing
- Detailed explanations for each step

## Local Setup

### Prerequisites
- Node.js 18+ 
- npm or yarn

### Installation

1. **Clone or download the project files**

2. **Install dependencies:**
\`\`\`bash
npm install
# or
yarn install
\`\`\`

3. **Run the development server:**
\`\`\`bash
npm run dev
# or
yarn dev
\`\`\`

4. **Open your browser and navigate to:**
\`\`\`
http://localhost:3000
\`\`\`

### Build for Production

\`\`\`bash
npm run build
npm start
\`\`\`

## Project Structure

\`\`\`
automata-simulator/
├── app/
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx
├── components/
│   ├── ui/
│   │   ├── button.tsx
│   │   ├── card.tsx
│   │   ├── select.tsx
│   │   ├── badge.tsx
│   │   └── table.tsx
│   ├── automata-converter.ts
│   ├── interactive-diagram.tsx
│   └── transition-table.tsx
├── lib/
│   └── utils.ts
├── types/
│   └── automata.ts
├── data/
│   └── problems.ts
├── package.json
├── tailwind.config.js
├── next.config.js
└── README.md
\`\`\`

## Usage

1. **Select Conversion Mode:** Choose from 10 different conversion modes
2. **Pick a Problem:** Select from 25 predefined problems
3. **Start Conversion:** Click "Convert" to begin step-by-step process
4. **Navigate Steps:** Use Previous/Next buttons or Auto-play mode
5. **Interact:** Click on states and transitions for detailed information

## Educational Value

- **Step-by-step learning:** Each conversion broken down into clear steps
- **Visual feedback:** Interactive diagrams show exactly what's happening
- **Multiple examples:** 25 problems covering various complexity levels
- **Detailed explanations:** Each step includes educational explanations
- **Progress tracking:** Visual progress bars and step counters

## Technologies Used

- **Next.js 14** - React framework
- **TypeScript** - Type safety
- **Tailwind CSS** - Styling
- **Radix UI** - UI components
- **Lucide React** - Icons
- **SVG** - Interactive diagrams

## Contributing

Feel free to contribute by:
- Adding more problems
- Implementing additional conversion modes
- Improving visualizations
- Adding new features

## License

MIT License - feel free to use for educational purposes.
