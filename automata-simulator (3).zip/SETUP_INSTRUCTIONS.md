# Local Setup Instructions

## Quick Start

1. **Download all files** and place them in a folder called `automata-simulator`

2. **Open terminal/command prompt** in the project folder

3. **Install dependencies:**
\`\`\`bash
npm install
\`\`\`

4. **Start the development server:**
\`\`\`bash
npm run dev
\`\`\`

5. **Open browser** and go to: `http://localhost:3000`

## Detailed Setup

### Step 1: Create Project Folder
\`\`\`bash
mkdir automata-simulator
cd automata-simulator
\`\`\`

### Step 2: Copy Files
Copy all the provided files maintaining the folder structure:
- `app/` folder with all React components
- `components/` folder with UI components
- `lib/`, `types/`, `data/` folders
- Configuration files (package.json, tailwind.config.js, etc.)

### Step 3: Install Dependencies
\`\`\`bash
npm install
\`\`\`

This will install:
- Next.js 14
- React 18
- TypeScript
- Tailwind CSS
- Radix UI components
- Lucide React icons

### Step 4: Run Development Server
\`\`\`bash
npm run dev
\`\`\`

The application will be available at `http://localhost:3000`

### Step 5: Build for Production (Optional)
\`\`\`bash
npm run build
npm start
\`\`\`

## Troubleshooting

### Common Issues:

1. **Node.js version:** Make sure you have Node.js 18 or higher
2. **Port conflicts:** If port 3000 is busy, Next.js will suggest an alternative
3. **Dependencies:** Run `npm install` again if you encounter module errors

### System Requirements:
- Node.js 18+
- 2GB RAM minimum
- Modern web browser (Chrome, Firefox, Safari, Edge)

## Features Available Locally:

✅ All 10 conversion modes  
✅ 25 predefined problems  
✅ Interactive diagrams  
✅ Step-by-step visualization  
✅ Auto-play mode  
✅ Responsive design  
✅ No internet required after setup  

## Development Commands:

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run start` - Start production server
- `npm run lint` - Run ESLint

Enjoy learning automata theory! 🚀
